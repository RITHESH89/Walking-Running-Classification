
# Walking vs Running Classification using LSTM

This project classifies human activity (Walking or Running) using accelerometer and gyroscope sensor data.

## Tech Stack
- Python
- TensorFlow / Keras
- LSTM
- NumPy, Pandas, Scikit-learn

## How to Run
```bash
pip install -r requirements.txt
python train.py
```
